Tech Launch Pad Design
=========